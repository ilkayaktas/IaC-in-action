---
name: Enhancement Request
about: Suggest an enhancement to the Kubespray project
labels: kind/feature

---
<!-- Please only use this template for submitting enhancement requests -->

**What would you like to be added**:

**Why is this needed**:
